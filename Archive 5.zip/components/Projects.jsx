import React from "react";
import netflixClone from "../public/assets/netflixClone.png";
import weatherApp from "../public/assets/weatherApp.png";
import speedGame from "../public/assets/other/speed-type.png";
import Image from "next/image";
import { FaGithub } from "react-icons/fa";

export const Projects = () => {
	const projects = [
		{
			id: 1,
			title: "Netflix Clone",
			dev: "Full-stack",
			imgSrc: netflixClone,
			url: "https://my-netflix-clone.co.uk",
			desc: "This is my version of Netflix. Using TMDB, this was a really fun project which tested my abilities and improved my knowledge. User's can explore their favourite movies and shows and save them to their profile. ",
			stack:
				"React | Hooks | JavaScript | NodeJS | Express | MySQL | RESTful | SASS",
			gitRepo: "https://github.com/Jmaltby19/netflix-clone",
		},
		{
			id: 2,
			title: "Weather App",
			dev: "Front-end (React)",
			imgSrc: weatherApp,
			url: "https://react-weather-app-drab-sigma.vercel.app/",
			desc: "This Weather app used the Open Weather API. This was one of my first projects to use React. A simple app which displays the users current weather and the weeks forecast",
			stack: "React | Hooks | JavaScript",
			gitRepo: "https://github.com/JMaltby19/react-weather-app",
		},

		{
			id: 3,
			title: "Speed Typing Game",
			dev: "Front-end (React)",
			imgSrc: speedGame,
			url: "https://speed-typing-game-orpin.vercel.app/",
			desc: "The speed typing game will count the amount of words typed within a set time.",
			stack: "React | Hooks | JavaScript",
			gitRepo: "https://github.com/JMaltby19/speed-typing",
		},
	];

	return (
		<div id="projects" className="w-full">
			<div className=" max-w-screen-xl mx-auto px-12 py-16 text-center md:text-left md:max-w-screen-2xl">
				<h2 className="text-5xl text-slate-300 md:text-7xl tracking-wider uppercase font-bold mx-10">
					Projects
				</h2>
				<h3 className="text-slate-400 text-xl md:text-xl tracking-wider font-light mx-10">
					Below are some of the projects I have been working on:
				</h3>
				<div className="max-w-8xl flex flex-col md:auto-cols-auto md:mx-8">
					{projects.map(
						({ id, title, dev, imgSrc, url, desc, stack, gitRepo }) => (
							// <Link key={id} href={`/projects/${url}`}>
							<div
								key={id}
								className=" z-0 cursor-pointer duration-200  bg-[#233554] group overflow-hidden rounded-md flex flex-col xl:flex-row my-8"
							>
								<a
									href={`${url}`}
									rel="noreferrer"
									target="_blank"
									className=" xl:w-3/5 flex justify-center items-center rounded-md opacity-40 hover:opacity-100 ease-in duration-500"
								>
									<Image src={imgSrc} alt={title} />
								</a>
								<div className="flex flex-col justify-around items-center mx-4l xl:w-2/5">
									<h2 className=" text-slate-300 text-center text-3xl my-0 font-semibold group-hover:underline underline-offset-2">
										{title}
									</h2>
									<h3 className=" text-slate-400 text-center font-medium">
										{dev}
									</h3>
									<p className=" text-teal-400 text-center font-semibold py-6">
										{stack}
									</p>
									<p className="text-slate-400 text-center pb-6">{desc}</p>
									<div className="z-50">
										<a
											href={gitRepo}
											rel="noreferrer"
											target="_blank"
											className="z-50"
										>
											<FaGithub
												size={40}
												className=" text-slate-300 hover:text-teal-300 mb-4"
											/>
										</a>
									</div>
								</div>
							</div>
							// </Link>
						)
					)}
				</div>
			</div>
		</div>
	);
};
