"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 6608:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
;// CONCATENATED MODULE: ./public/assets/other/jm_logo-removebg-preview.png
/* harmony default export */ const jm_logo_removebg_preview = ({"src":"/_next/static/media/jm_logo-removebg-preview.66b9e0d8.png","height":487,"width":513,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAArElEQVR42jWOPQ4BQRiG9wTbigMokBUaB3ADSglR6SmpZM2uE7iCkjO4ghEXECOhkUj8JMLz2tlJnrxv5nsy3wQ6xtkmDKCbOhsmzhbpPTLMhfXc2a+gt8mx79W/gCmpH592ulwy3MSZUNGghBCRHQkMz3ADCVFAmcFFO/2aN3zgCTUJEzgk2e47bA2QV2hImMIDVkqGQxjRX2Rdf2jJ9tJx4faFlKd1Z5wt/wBzeaxF4yNxcAAAAABJRU5ErkJggg=="});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Navbar.jsx






const Navbar = ()=>{
    const { 0: nav , 1: setNav  } = (0,external_react_.useState)(false);
    const links = [
        // { id: 1, link: "home" },
        {
            id: 2,
            link: "about"
        },
        {
            id: 3,
            link: "projects"
        },
        {
            id: 4,
            link: "skills"
        },
        {
            id: 5,
            link: "contact"
        }, 
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full h20 z-10 fixed bg-[#0a192f] text-black duration-300 ease-in",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between items-center w-full max-w-screen-xl mx-auto p-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/#about",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: jm_logo_removebg_preview,
                            alt: "logo",
                            height: "50px",
                            width: "50px"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "hidden md:flex justify-items-end ",
                                children: [
                                    links.map(({ id , link  })=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: `/#${link}`,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "text-teal-300 ml-10 mt-1 text-sm uppercase cursor-pointer duration-200 ease-out hover:scale-125 tracking-wider ",
                                                children: link
                                            })
                                        }, id)),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "/John_Maltby CV-1.pdf",
                                            target: "_blank",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: "hidden group md:flex items-center justify-center text-center ml-10 rounded-md text-teal-300 border-2 border-teal-300 w-14 duration-200 ease-out hover:scale-125",
                                                children: "CV"
                                            })
                                        })
                                    })
                                ]
                            }),
                            !nav && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "md:hidden cursor-pointer text-slate-300",
                                onClick: ()=>setNav(true),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaBars, {
                                    size: 20
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: nav ? "md:hidden fixed left-0 top-0 w-full h-full bg-black/20 backdrop-blur duration-200" : "",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: nav ? "fixed right-0 top-0 w-4/5 h-full bg-slate-300 text-[#0a192f] p-10 ease-in duration-500" : "fixed top-0 right-[-100%] p-10 h-full ease-in duration-500",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " flex w-full justify-end",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "p-auto cursor-pointer",
                                    onClick: ()=>setNav(false),
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTimes, {
                                        size: 20
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-24 flex flex-col h-fit gap-20",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    className: "uppercase",
                                    children: [
                                        links.map(({ id , link  })=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: `/#${link}`,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    onClick: ()=>{
                                                        setNav(false);
                                                    },
                                                    className: "text-[#0a192f] py-4 text-2xl tracking-wider duration-200 ease-out hover:scale-105 cursor-pointer",
                                                    children: link
                                                })
                                            }, id)),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "/John_Maltby CV-1.pdf",
                                                target: "_blank",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "flex items-center justify-center text-center ml-6 rounded-md text-[#0a192f] border-2 border-[#0a192f] w-14 duration-200 ease-out hover:scale-125",
                                                    children: "CV"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "grid grid-cols-4 mx-auto ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "https://github.com/JMaltby19?tab=repositories",
                                                rel: "noreferrer",
                                                target: "_blank",
                                                className: "flex items-center justify-center p-3 duration-200 ease-out hover:scale-105 cursor-pointer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaGithub, {
                                                    size: 50
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "https://www.linkedin.com/in/john-maltby-4a822344?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BMys6VS3pRTGDX7K9XEWnXg%3D%3D",
                                                rel: "noreferrer",
                                                target: "_blank",
                                                className: "flex items-center justify-center p-3 duration-200 ease-out hover:scale-105 cursor-pointer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaLinkedin, {
                                                    size: 50
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex items-center justify-center p-3 duration-200 ease-out hover:scale-105 cursor-pointer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaInstagram, {
                                                    size: 50
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex items-center justify-center p-3 duration-200 ease-out hover:scale-105 cursor-pointer",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTwitterSquare, {
                                                    size: 50
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};

// EXTERNAL MODULE: ./components/SocialBar.jsx
var SocialBar = __webpack_require__(5173);
// EXTERNAL MODULE: ./components/TabHeader.jsx
var TabHeader = __webpack_require__(4601);
;// CONCATENATED MODULE: ./pages/_app.js





function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(TabHeader/* TabHeader */.G, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(SocialBar/* SocialBar */.Y, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [377,675,952,664,217], () => (__webpack_exec__(6608)));
module.exports = __webpack_exports__;

})();