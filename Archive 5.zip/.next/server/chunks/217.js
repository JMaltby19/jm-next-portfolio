"use strict";
exports.id = 217;
exports.ids = [217];
exports.modules = {

/***/ 5173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ SocialBar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _skillsData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7065);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__);





const SocialBar = ()=>{
    // const socials = () => {
    // 	return socialImgs.map((item) => {
    // 		return (
    // 			<ul key={item} className="">
    // 				<li className="pb-2">
    // 					<div className="">
    // 						<Image url={item} alt="icon" width="40px" height="40px" />
    // 					</div>
    // 				</li>
    // 			</ul>
    // 		);
    // 	});
    // };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: " hidden md:flex flex-col fixed items-center mx-0 px-0 left-6 top-80",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://github.com/JMaltby19?tab=repositories",
                        rel: "noreferrer",
                        target: "_blank",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaGithub, {
                            size: 40,
                            className: " text-slate-300 hover:text-teal-300 mb-4"
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "https://www.linkedin.com/in/john-maltby-4a822344?lipi=urn%3Ali%3Apage%3Ad_flagship3_profile_view_base_contact_details%3BMys6VS3pRTGDX7K9XEWnXg%3D%3D",
                        rel: "noreferrer",
                        target: "_blank",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaLinkedin, {
                            size: 40,
                            className: " text-slate-300 hover:text-teal-300 mb-4"
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaInstagram, {
                        size: 40,
                        className: " text-slate-300 hover:text-teal-300 mb-4"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaTwitterSquare, {
                        size: 40,
                        className: " text-slate-300 hover:text-teal-300 mb-4"
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 4601:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ TabHeader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);



const TabHeader = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: "John Maltby | Portfolio"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                    rel: "icon",
                    href: "favicon.ico"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                    rel: "icon",
                    type: "image/ico",
                    sizes: "16x16",
                    href: "favicon.ico"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                    rel: "icon",
                    type: "image/ico",
                    sizes: "32x32",
                    href: "favicon.ico"
                })
            ]
        })
    });
};


/***/ }),

/***/ 7065:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ZU": () => (/* binding */ skillsData)
});

// UNUSED EXPORTS: skillsImgs, socialImgs

;// CONCATENATED MODULE: ./public/assets/652581_code_command_develop_javascript_language_icon.png
/* harmony default export */ const _652581_code_command_develop_javascript_language_icon = ({"src":"/_next/static/media/652581_code_command_develop_javascript_language_icon.a42f74e4.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAuElEQVR42mN4f8uPiQEKXl/3U3pxxVeJAQre3oDKvb3pJ/jhtv/mT3f9v3++B8abX171FWSAgY9AyTc3/P4/ueDz/84JLzANVLwZZowSSOeLy77/V862/zer1/bfjWOe/0EmAU1RYngFJL7cD/h+bo/7/61Lnf7tWOH0b9Nix//fHgR8B5oEcQ/IuLunIEbfOOr5H2TaxztAK6AAZIrg1wcBYEeCTANpeH3NVxDqA1RvPr8M9iZcDgCSsH7OyIF5JwAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/7423888_react_react native_icon.png
/* harmony default export */ const _7423888_react_react_native_icon = ({"src":"/_next/static/media/7423888_react_react native_icon.f9ab2e8d.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAeFBMVEVh2vtg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fpg2fon9krbAAAAKHRSTlMAAAIDFhgcHh8hIyQmP0BBSkxNZmhpbG1vcnd7fH1+f4CBhIWGk5SV2XvyhgAAAEtJREFUeNoNy9kWQCAQANAZRJaQNUvLUPz/H9bzPReQq7pVJQJOzFg2ImSXIdInwDqE9/nFDEv/eR/Elsg6R3cOKAvSTKZV7U13cIylswSfJOSUrwAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/65687_html_logo_html5_5_five_icon.png
/* harmony default export */ const _65687_html_logo_html5_5_five_icon = ({"src":"/_next/static/media/65687_html_logo_html5_5_five_icon.ceadcd19.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA4klEQVR42mOAAnMGNskZDBLqRQxiKnMYOGRnMjAwcDLAwE1vjfgrvAzNtxkYiq8zMFScZmCYcMVbKwWu4Kmn1Ilntfn/n0/v+/9l5Zz/X2e2/X/pz30cruCxBsPiF6dP/n957NCP7ycP/vi6bsH/5+4MixEKpBkmPFu7/P/LQ/t+/7h05vfXbav/P5VjmIBQwMBQ+Wzl4v/PF8389f3wrl8/Lp7+DxJDKJBiSH/aWPr/5ZGD/39ePvv/Q0/5/8fiDOlwBU/i3ZQeqzIseaLL8PyFJcPzp0YMSx7HeigxMDAwAABFLWhMRGTuNgAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/294692_css3_icon.png
/* harmony default export */ const _294692_css3_icon = ({"src":"/_next/static/media/294692_css3_icon.c681a563.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA7klEQVR42j3JPUgCYRzA4Z/UGE05N8S1RWKURUku0Zir0MdQHegQDQUFbSrUEBVBEF5IUCYRRE0eUkNJJREtDip+oaOLiA6eyN/tfdYHbW5jAGDCzqJjjDXHOP7JUTwA2rRvEICZQNLO8N4mbO/C+gHsbM3730ZQVu6Cvv0XCYTM1uF9pqlH/oXVpyCKM6qHLpNSKFV77Y7VuzKLwlJcRxkyvEenCfn5y3aztUb3OpEXuPGCcuE+i7xL7PXX+s7VredUWeDEjbJwq3n0RzHiX/LwUZHl45TAuaY+nanYmI26wAgzFQvjNFxp89MG0Ad+a1uYioTpywAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/4375066_logo_sass_icon.png
/* harmony default export */ const _4375066_logo_sass_icon = ({"src":"/_next/static/media/4375066_logo_sass_icon.a693160c.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAeFBMVEXPZJrPZJnOY5nOZJnOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5nOY5mIzK2kAAAAKHRSTlMAAAABAQIDBgsMDhYYGx4jJSorLD9CTFRXWlxjZ29wc3SBhYeNm6CmR2/28wAAAEVJREFUeNpjYGNiYmBiAhHcMnLiIJ6wshCrAjsTK4OKAIekqCAzEwOPhLSSoroYPwOvvJqqghQXH4OILCcbIxNMKxsTCwB5/ANo+npgZAAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/9118036_nextjs_fill_icon.png
/* harmony default export */ const _9118036_nextjs_fill_icon = ({"src":"/_next/static/media/9118036_nextjs_fill_icon.059927b9.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAZElEQVR42iXLsQnCUAAG4W8Kh3gOZ+cONoJgKekcwFYsDDiBG9iK5pUxWvwGHgcHVxwUV18/vdLyLRqDQi/OnqqL6BnF2srDRox8RGdn7ySmtnQGW/e2FFXEy1G1xKybSRws+AMPnS0qu4PVdgAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/frontend/typescript.png
/* harmony default export */ const typescript = ({"src":"/_next/static/media/typescript.37adc0f3.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA6klEQVR42iWNsUrDUBiFvz+9MQZSDNbhFkQdCi52cNDFrm4+g4/g6nv4BD6Ag12cXVrERQS3ItiiNgiaaoNWuMnvDZ7lHM43fLJ7OpgiYtXHtwDgt/j4yoyCDYCo8U+dAn6GAotKrPG/fpUqo5kDBJaEZkOYzx2dNFTz6VS6qeFkfxVVeM1/mf2U9LZX6N99iKmAGhzstNiwCVfDF4566wzu32otQTsSvRwv6A8zxtOC4/MJD485thVjAtHAKVJ715ohy1GDvU7M6Llgq51w2E3FuIpsMw7s7VOh+beTUiFNQr24nsjZzXv2B8InXCO5V91nAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/frontend/greensock.svg
/* harmony default export */ const greensock = ({"src":"/_next/static/media/greensock.ebf2da98.svg","height":440,"width":1200});
;// CONCATENATED MODULE: ./public/assets/nodejs_original_wordmark_logo_icon_146412.png
/* harmony default export */ const nodejs_original_wordmark_logo_icon_146412 = ({"src":"/_next/static/media/nodejs_original_wordmark_logo_icon_146412.ad9fd333.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAnUlEQVR42mMgCCy1zZnCq40Zu26pMbmHmDEyAIGtuTlT3nJ9xvar6owMBIGVjrleeKWxcv9jZQ1XfzMtewfzXDtbc/XMeQZiHdfUhRlMBSxKY9uNSjtvqO3wjDJts7Uyn+zsbdZVtlXXuuWChh/cJKBqVl0GC1agO1iArmA6/Z+Bse6oFguDqz/YYYQB0BeMDk5mjA7OZowWSuZwTQCF4Ceg00veygAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/express_original_wordmark_logo_icon_146528.png
/* harmony default export */ const express_original_wordmark_logo_icon_146528 = ({"src":"/_next/static/media/express_original_wordmark_logo_icon_146528.8398ff7f.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAANUlEQVR42mMgAjCCMROIBEMGYwZTBn0GPQYzBiMGAyDNIMMgwaABxKIMUgzSQIgJGFEhhjwAq28CdPLrdGkAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/assets/phpmyadmin-icon-5606.png
/* harmony default export */ const phpmyadmin_icon_5606 = ({"src":"/_next/static/media/phpmyadmin-icon-5606.2e77c3da.png","height":463,"width":647,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAnElEQVR42mPADvQ4GBjSmVCEDkxKYgTRDWWZ/PsnBFtdnOXrzYANPF0VGPV+hUXnt2Xyp/+vYNADC+aVtLJsrmpgubMwWPbRoqA9d2dFnDnfF3/6aHNgEENz47SiyvqZc49NLV9wcWbOxqOTSnft6q05tqm7/uDipko5hrq6iWJ1dRPE5zeXC5yaliP3fy0D8/8dDKz/HwDpZwyMAEBvP75F+Yv+AAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/backend/pngegg.png
/* harmony default export */ const pngegg = ({"src":"/_next/static/media/pngegg.35e1f0fa.png","height":412,"width":787,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAVElEQVR42mMwmnGrCohdgTgbiG0Y0AFQsAuIHYE4F4gjgTgciKOBOAuIw2AK3IG4AIiDgDgaiEuBuBaI6xigVqQCcQUQW4JNnXmb2WjGbR4GBgYGABhSNBIEFMVyAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/mongodb_original_wordmark_logo_icon_146425.png
/* harmony default export */ const mongodb_original_wordmark_logo_icon_146425 = ({"src":"/_next/static/media/mongodb_original_wordmark_logo_icon_146425.9a98058d.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA3UlEQVR42mMAgfA17swgOmqdl0fgckdbENt/qT1YjMF3pT0jiBacJ8oWusbthddi6zsMUOC2wJyRwX2pJVilyxJzd7+VDv/d5pr/d5hu6AISc55lwgySYAZzlpi5eiyz/u880/S/w1QjD5CY+zRTFgafHH2mIgZnsDWei62vuE4zvw9kgjVF9tiBxBFg6aF+xaX7+zVB7NqVZUxgwQALbe0AM209Hyt1g2gzK4MAFQuNxix/m2lVcQGTK2L8QArU/M219P3NdNT9rDQ83YwUXZozA5WnVcepT66I0QAAgow+Ax/mNloAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/assets/1175544_firebase_google_icon.png
/* harmony default export */ const _1175544_firebase_google_icon = ({"src":"/_next/static/media/1175544_firebase_google_icon.4359f797.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAr0lEQVR42mMAgX/zGRgZoODfVinm/2c0mRiAACbJBKUd/i9nlmGAAqAiiKb/CxlYITRj3785DPf+reJP/n9Jxwas6aQ6E8PvSczMYM5shnU/egT+/zuo/B+oewNY7JQGCwMM/JrCd/33TtX//89q/gfqvMqADH4YMnD+3a/y6P8ZDZDk//+nNB78P6nOAZb8t02WEUT/v6kjDpRcCJScD6RFoG5ghCjaJc/IgASQJQHQMlFxGByX9AAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/211904_social_github_icon.png
/* harmony default export */ const _211904_social_github_icon = ({"src":"/_next/static/media/211904_social_github_icon.e7643f1b.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAYElEQVR42k3IsQmDABQA0UfqFIZsEQIOENIkGSGVlTPYW4lgpUPYOJVY6BKC6C/lqndckCqjFCFymz3a5PC0+npHP2tIYwQwhbTm0+j4WFQSV73dCwqDxCNYA2Ru7v5wAErdFl7W+udJAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/ubuntu_plain_wordmark_logo_icon_146632.png
/* harmony default export */ const ubuntu_plain_wordmark_logo_icon_146632 = ({"src":"/_next/static/media/ubuntu_plain_wordmark_logo_icon_146632.f329a220.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAArklEQVR42k2OIQpCQRCGR4/gbBHsVoPBJoKwGywWBdFgEHzN6AW8gohW3wHE5AVMFoNYdnhn8ATPLyhvB37mn/m/WVZi0LpQ5t3WgvtY0DdaC0VWk59ZAZToBDRHL3wm/2KRA2XRa4EvCJn1ngCaszwAXMzrmfmKbinQ47IEetB39CfwQNIiaKMjwT7iq8Brk4sJ6vNSA6hDH7LvopYQTDELgiXa8DlmN8aPLOjsC59tVNNXye8zAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/npm_original_wordmark_logo_icon_146402.png
/* harmony default export */ const npm_original_wordmark_logo_icon_146402 = ({"src":"/_next/static/media/npm_original_wordmark_logo_icon_146402.cd33b30b.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAeFBMVEXLODfKODfLNzfLODfKODfLNzfKNzfLODfKODfLNzfKODfKODfKODfKODfKODfLNzfLNzfKNzfLNzfLNzbLNzfLODfLNzfLNzfLNzfKNzfLNzfLNzfLNzfLODbLODfLNzfKODfLNzfKNzfLNzfKNzfLODfKODfLODZePFUnAAAAKHRSTlMAAAACAgICAwMDLC8xMjw+QEJHYGZpa25wcHV4fX5/gISKio+dnqazZDz4eQAAAEhJREFUeNodxFcWQDAQBdCXMcEQvRO97X+HnNyPC9GiA08LiAiuqV2bpa9HDKXN56zacVxncW/vgzjpbGpMBKWI1A/si4TM/AGBzAOCG9PJ+AAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/docker_plain_wordmark_logo_icon_146555.png
/* harmony default export */ const docker_plain_wordmark_logo_icon_146555 = ({"src":"/_next/static/media/docker_plain_wordmark_logo_icon_146555.a72962e6.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAArklEQVR42mWOPQoCQQyFE8RKrRW8gq2NC7IoriBsY+lfI9pYiCewsvMCzpxncggvYSEo2KzfIFjsBh4vb95LJvIvHxqgry60pFIu9ECuznJCXXFWBzvQZNIGmFv1tsBcsmFFn/L+5P0q6sMDo0C84Rf6w6aCwF5iMXHEvGHeo0EgmpfyDW0CGTgQSITiG0XXhPSaY85gTj/G2MCn35FhGgMpIoFH8AQM6Wdwpt46XzugXn/tfJ53AAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/heroku_plain_wordmark_logo_icon_146480.png
/* harmony default export */ const heroku_plain_wordmark_logo_icon_146480 = ({"src":"/_next/static/media/heroku_plain_wordmark_logo_icon_146480.7904c43a.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAsUlEQVR42k2OoQoCQRCGD1/BZBGTBo2a9QlEm2A4ZsNsMJxNRMRsNBtlNopPcsWmx4FJ8CX0E9zDhZ/Zf+ebfyf5Hu9C3TvL1VnBvVAXrtRREo+X0FEAtKJxBrirhHkFqFiLRonWXkwZuAHN/hKsycMDvbmfqBeUVgCmzQ4v9CQtJ6FEEuNrv7ph+oD2fHVEjTidQY95GAJ18X18CjggsQdgU8wOk9GcsP0SvwVSlbD4ANwdY7sm6sfVAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/file_type_vscode_icon_130084.png
/* harmony default export */ const file_type_vscode_icon_130084 = ({"src":"/_next/static/media/file_type_vscode_icon_130084.e581ec5f.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA0UlEQVR42mNgqDzNxFB9npkhZxszAxQI1J5IlZ/zQY8BK4idP4W7dO9/+Xmf/sjNehfHADQhnKHqzAqGxMXcDCnLNzIkLv3PW3V4j/zcT//lZr+bxMBQf0WSofrcBYbyE/8ZMtf/Y/Bqc1Re/t9Ibvb7/0DcysAQMUWSIXXlBYbSo/8Zas7/Yyg+7qi86DuSgrRV4UCjVzAEdXEzVJ3dyFB+8j9v2w2gFR9BCiYxYIDS41O4m6/+Byr4A1QQx8CQuoqJIWkJM0PxQYQ3O27BvQkAPLFdjmt3Xz8AAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/assets/file_type_photoshop_icon_130268.png
/* harmony default export */ const file_type_photoshop_icon_130268 = ({"src":"/_next/static/media/file_type_photoshop_icon_130268.881fae2f.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA7ElEQVR42mPQ3XrPRmPR8TK1eYfy1ecfLtBYdKxAfcHRfCBdprvtng2D2ux9/UIuUf8F7UP+C9oG/+fXcfzPp23/X9gt5j9IjkFl6o52PlWr/8r9G38C8R8hh7A//EbuP3kVzf6rTtvZzqAybUeHgIXvf9Xpu/4oT9ryX23Ogf/y9fP+8Ahq/VeduacDosDE8z/Q/j/CHvH/pbLbwGw+dRuQJqCCqdvb+bTs/4v4pvxkYWD4Ix5V/Ecyveknj4gO2AqII12j/4PcIWgT9B+kmFdSH+jIWIgjdbdBvAn0Vr76giMFQDYI56tDvQkAljp3E/ENZ7EAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/assets/figma_logo_icon_170157.png
/* harmony default export */ const figma_logo_icon_170157 = ({"src":"/_next/static/media/figma_logo_icon_170157.a6d13c99.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA4ElEQVR42mMAgY9+6tEffHX+fwow/vu3IPHP35L0//+KkmMYYOCTn8jirz4M/78FMvz9nxv6/3+O3///hfFL4Are+fur3Q6a8/m+74zPb2q7Tl2bsOrT9/IyNbiCWbH/G2fF/P8/M+7/W4Zd/68zHPj/n2Hf/wa4gmU+/xtXuP//D6TfOWz9+0Jlz5//Orv+dMAV6J7qV43fvP1bysbtLxx3PNPm2fPf23bHK2a4AqbzjYsYLpf/Z7hc9p7hHgM3TFxqzz9GMEPgXEuk6NnW/9Jn25eC+NyHnrIqHngAlgQAx9Rr86RX+ksAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/assets/file_type_jest_icon_130514.png
/* harmony default export */ const file_type_jest_icon_130514 = ({"src":"/_next/static/media/file_type_jest_icon_130514.169c2164.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA8ElEQVR42mP49+8fIwMQ/P//n+vj/buNL04e63xx4mjHhzu32v7//y8MkmCMYGBgZgCCh9s2nT6dGPj/dELA/3trlt8GyTEgg9cXzyU82bvr4ZP9u+++PH2iHC7x9MDeja8vni9/debU9LfXrqz/eP/e9JenT+5E6Lxw9vHnJ4+TPty9M+f6tP7/l5oq/wFNefn//39uhj8/f6rdW7vi9ZvLF3suNpS9PKLH8P9UlMf/h1s3Xv7//z8zw////5WuT5/w62Sk+//L7fV/nx7cu+TTg/tp////l4Zb8e31K883Vy42////X5sBCfz6+oURAJo7kyxbXn2CAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/kisspng-logo-cpanel-computer-software-portable-network-gra-5b77735f340a86.7114469815345549752132.png
/* harmony default export */ const kisspng_logo_cpanel_computer_software_portable_network_gra_5b77735f340a86_7114469815345549752132 = ({"src":"/_next/static/media/kisspng-logo-cpanel-computer-software-portable-network-gra-5b77735f340a86.7114469815345549752132.266b1e45.png","height":600,"width":600,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAeFBMVEX3cTXzbDHybDHyazDyazDzbDHyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDyazDU3MuxAAAAJ3RSTlMAAAAAAQICBA0cKy5FRktQWVtcYWV5hZqeo7O2vcjK0NLc3efv+vzMgFe3AAAASElEQVR42h3LRRKAMBAEwB0GElyDuyX//yFV9L0FSiuCIgFJ0zcQxHXutreTwt7zhWmXdcFwnDYV48anTSJPkFVlSAb/ovbxAYVbA6qQI9YQAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/new-linkedin-logo-white-black-png.png
/* harmony default export */ const new_linkedin_logo_white_black_png = ({"src":"/_next/static/media/new-linkedin-logo-white-black-png.0dc1234e.png","height":1600,"width":1600,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAcklEQVR42iXJIQ6BcRyA4SfbVF10AOMATuAEGgJJsUkkLkH6qk1zBXdQbQiMfQQff7/tK094X9aS5OOrkCwEY7vwJ4arYGYfPpzDk6BrqaWpKvMiaZio2erpKEjqRioOhtplmMoMHG2s5My93eQu7p76f4T7LQ1uXe7aAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./public/assets/25231.png
/* harmony default export */ const _25231 = ({"src":"/_next/static/media/25231.ebcf7a0b.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAZUlEQVR42g3HIQrCYBgA0BeGIGiyDvQSZrF4Aau3MSiYvYNxwSO4aPgR9A6G7QIb3z5eelBr/FOjho2iN6ZOyWl9sU78vAgXAFdBuKFKnAVvHyczlaNBYefpbmEl0hYOHuaWWnsmIygcxVjt4rEAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/assets/instagram-black-logo-1024x1024.png
/* harmony default export */ const instagram_black_logo_1024x1024 = ({"src":"/_next/static/media/instagram-black-logo-1024x1024.a93dd64b.png","height":1024,"width":1024,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAXklEQVR42g3BsQ2CQAAAwOvohdjpAsY4gzHsYoyLWLgG8bXSf4uHimcx/o6zWRJ86qSnOKHT2Hn4k3A1+XraexNsZPDTeBG0MhhtDUTc5PqOSHFEq8PBwkURDXW06Fc3Mhsk9gGPcwAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./public/assets/black-lines-twitter-icon-symbol-18.png
/* harmony default export */ const black_lines_twitter_icon_symbol_18 = ({"src":"/_next/static/media/black-lines-twitter-icon-symbol-18.2e2839ab.png","height":1200,"width":1200,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAX0lEQVR42iXHOwqCAAAA0EdBRC7R0Bn6QZ2gNai1A4iToIsOiqC4uLm7eApvqCBvegAQAGe5nUAl1fvx1YqNHihk/BdcQeLIQW0DTkp4mryx17nBxyASarywBe4urJ0BQ7EMFWzGXFMAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./components/skillsData.js




























const skillsData = [
    {
        name: "JavaScript",
        img: _652581_code_command_develop_javascript_language_icon
    },
    {
        name: "React",
        img: _7423888_react_react_native_icon
    },
    {
        name: "HTML",
        img: _65687_html_logo_html5_5_five_icon
    },
    {
        name: "CSS",
        img: _294692_css3_icon
    },
    {
        name: "SASS",
        img: _4375066_logo_sass_icon
    },
    {
        name: "Next.js",
        img: _9118036_nextjs_fill_icon
    },
    {
        name: "TypeScript",
        img: typescript
    },
    {
        name: "Greensock",
        img: greensock
    },
    {
        name: "Node.js",
        img: nodejs_original_wordmark_logo_icon_146412
    },
    {
        name: "Express",
        img: express_original_wordmark_logo_icon_146528
    },
    {
        name: "Php",
        img: phpmyadmin_icon_5606
    },
    {
        name: "SQL",
        img: pngegg
    },
    {
        name: "MongoDB",
        img: mongodb_original_wordmark_logo_icon_146425
    },
    {
        name: "Firebase",
        img: _1175544_firebase_google_icon
    },
    {
        name: "Github",
        img: _211904_social_github_icon
    },
    {
        name: "npm",
        img: npm_original_wordmark_logo_icon_146402
    },
    {
        name: "Ubuntu",
        img: ubuntu_plain_wordmark_logo_icon_146632
    },
    {
        name: "Docker",
        img: docker_plain_wordmark_logo_icon_146555
    },
    {
        name: "Heroku",
        img: heroku_plain_wordmark_logo_icon_146480
    },
    {
        name: "VS Code",
        img: file_type_vscode_icon_130084
    },
    {
        name: "Photoshop",
        img: file_type_photoshop_icon_130268
    },
    {
        name: "Figma",
        img: figma_logo_icon_170157
    },
    {
        name: "Jest",
        img: file_type_jest_icon_130514
    },
    {
        name: "CPanel",
        img: kisspng_logo_cpanel_computer_software_portable_network_gra_5b77735f340a86_7114469815345549752132
    }, 
];
const skillsImgs = [
    _652581_code_command_develop_javascript_language_icon,
    _7423888_react_react_native_icon,
    _65687_html_logo_html5_5_five_icon,
    _294692_css3_icon,
    _4375066_logo_sass_icon,
    _9118036_nextjs_fill_icon,
    typescript,
    greensock,
    nodejs_original_wordmark_logo_icon_146412,
    express_original_wordmark_logo_icon_146528,
    phpmyadmin_icon_5606,
    pngegg,
    mongodb_original_wordmark_logo_icon_146425,
    _1175544_firebase_google_icon,
    _211904_social_github_icon,
    npm_original_wordmark_logo_icon_146402,
    ubuntu_plain_wordmark_logo_icon_146632,
    docker_plain_wordmark_logo_icon_146555,
    heroku_plain_wordmark_logo_icon_146480,
    file_type_vscode_icon_130084,
    file_type_photoshop_icon_130268,
    figma_logo_icon_170157,
    file_type_jest_icon_130514,
    kisspng_logo_cpanel_computer_software_portable_network_gra_5b77735f340a86_7114469815345549752132, 
];
const socialImgs = [
    new_linkedin_logo_white_black_png,
    _25231,
    instagram_black_logo_1024x1024,
    black_lines_twitter_icon_symbol_18
];


/***/ })

};
;